# pylint: disable=missing-docstring
VAR = 'pylint'  # [unused-variable]
